package cloud.watermarking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudWaterMarkingApplicationTests {

	@Test
	void contextLoads() {
	}

}
