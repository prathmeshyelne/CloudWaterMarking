package services;

public class GetURL {
public static String getPythonServerURL()
{
	return "http://localhost:80/CloudWaterMarkingPython/";
}
 
}
